<?php 
session_start();
?>
<!DOCTYPE>
<html id="login-page">
    <head>
        <title >Login Form</title>
        <link rel="stylesheet" type="text/css" href="styles/newstyle.css" >
    </head>

    <script type="text/javascript">
            function validateEmail(){
                
                var email=document.admin_login.email.value;
                var emailPattern=/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{3}$/;
                
                if(email==""){
                    alert("Email must be filled out");
                }
                else if(emailPattern.test(email)==false){
                    alert("Invalid email address");
                    return false;
                }    
                return false;
            }

            function validatePassword(){
                var password=document.admin_login.password.value;
                var passwordPattern=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,12}$/;

                if(password==""){
                    alert("Password must be filled out");
                }
                else if(password.match(passwordPattern)){
                     return true;
                }
                else{
                    alert("Paswword must be of length 6 to 12 characters which contain atleast one lower case, one upper case letter and one numeric digit ");
                    return false;
                    }
            }
        
        </script>
        
    <body id="login-page" >
        <div class="login" action="login.php">
            <h2><?php echo @$_GET['not_admin'];?></h2>
            <h2><?php echo @$_GET['logged_out'];?></h2>
                <h3 class="agileinfo_sign">Admin Login</h3>
            <form method="post" name="admin_login">
                <div class="styled-input">
                <label>Email</label><br>
                <input type="text" name="email" onblur="validateEmail()"/><br><br>
                </div>
            
                <div class="styled-input">
                <label>Password</label><br>
                    <input type="password" name="password" onblur="validatePassword()" /><br>
                </div><br><br>
                <button type="submit" class="btn btn-primary btn-block btn-large" name="login" onclick="validateEmail(); validatePassword();">Let me in.</button>
            </form>
        </div>

        
    </body>
</html>


<?php 
    include("includes/db.php");
    if(isset($_POST['login'])){
        $email=$_POST['email'];
        $pass=$_POST['password'];
        $sel_user="select * from admins where user_email='$email' AND user_pass='$pass'" ;
        $run_user=mysqli_query($con,$sel_user);
        
        $check_user=mysqli_num_rows($run_user);

        if($check_user==1){
            $_SESSION['user_email']=$email;
         echo "<script>window.open('index.php?logged_in=You are successfully logged in !','_self')</script>";
           
        }
        else{ //this user does not have login credential
            echo "<script>alert('Password or Email is wrong,Try again !')</script>";
        }

    }
?>