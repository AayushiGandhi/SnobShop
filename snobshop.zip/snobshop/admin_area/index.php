<?php 
    session_start();
    if(!isset($_SESSION['user_email'])){ //if the user has not logged in
        echo "<script>window.open('login.php?not_admin=You are not an Admin!','_self')</script>";
    }
    else{
?>
<!DOCTYPE>

<html>
    <head>
        <title>Admin Panel</title>
        <link rel="stylesheet" type="text/css" href="styles/newstyle.css" media="all" />
    </head>
    <body>
        <div class="main_wrapper">
            <div id="header">
                <h2 id="head">Manage Your content<h2>
            </div>
            <div id="right">
                <h1 id="righthead">Manage content</h1>
                <a href="index.php?insert_product">Insert New Product</a>
                <a href="index.php?view_products">View All Products</a>
                <a href="index.php?view_customers">View Customers</a>
                <a href="logout.php">Admin Logout</a>
            </div>
            <div id="left">
                <h2 id="status"><?php echo @$_GET['logged_in']; ?></h2>
                
              <?php 
              if(isset($_GET['insert_product'])){
                    include("insert_product.php");
              }

              if(isset($_GET['view_products'])){
                include("view_products.php");
              }

              if(isset($_GET['view_customers'])){
                include("view_customers.php");
              }
          
              ?>
            </div>
        </div>
        
    </body>
</html>
    <?php } ?>