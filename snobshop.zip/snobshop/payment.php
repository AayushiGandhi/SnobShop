<div>
    <h2 style="text-align:center;">Pay Now With PayPal</h2>
    <p style="text-align:center;"><img src="paypal.png" width="200px" height="150px"></p>
</div>