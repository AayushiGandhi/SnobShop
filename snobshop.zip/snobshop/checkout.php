<!DOCTYPE>
<?php session_start(); 
      include("functions/functions.php"); 
      //include("includes/db.php");
?>

<html>
    <head>
        <title>Homepage</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="styles/newstyle1.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		
        
    </head>

    <body>
        <header>
        <!-- header -->
        <div class="headercontainer">
            <div class=" row header-bot">
                <div class="inside-header">
                    <div class="col-md-4 header-middle">
                        <form action="#" method="post">
                            <input type="search" name="search" placeholder="Search here..." required="">
                            <button type="submit" class="searchbutton"><i class="fa fa-search" aria-hidden="true"></i></button>
                            <div class="clearfix"></div>
                        </form>
                    </div>
                    <div class="col-md-4 logo">
                        <p>The Snobshop</p>
                    </div>
                    <div class="col-md-4">
                        
                    </div>
                </div>
            </div>
            <div class="row ">
                <nav class="navbar navbar-inverse navi">
                    <div class="container-fluid navcon">
                        <ul class="nav navbar-nav navibar">
                        <li class="active"><a href="index.php">Home</a></li>
                        <li><a href="cart.php">Shopping Cart</a></li>
                        <li><a href="#fcontact">Contact Us</a></li>
                        </ul>
                    </div>
                </nav>
            </div>

        </div>
        </header>

        <main >
            <div class="main-wrapper">
                <div class="col-md-2 sidebar">
                    <div id="sidebar_title">Categories</div>
                    <ul id="cats">
                        
						<?php getCats(); ?>																																			
                    </ul>
               
					<div id="sidebar_title">Brands</div>
                    <ul id="cats">
                        
                        <?php getBrands(); ?>
                        
                    </ul>
                </div>

                <div class="col-md-10 content" style="background-color:white;">
                    <div id="shopping_cart">
                        <?php cart(); ?>

                        <?php 
                            if(isset($_SESSION['customer_email'])){
                                echo "<b>Welcome: </b>" . $_SESSION['customer_email'] ;
                            }
                            else{
                                echo "<b>Welcome Guest: ";
                            }
                        ?>
                        <!-- <span> Welcome Guest !</span> -->
                        <!-- <b>Shopping Cart </b>
                        Total Items: < ?php total_items(); ?> Total Price: < ?php total_price(); ?> -->
                        <a href="cart.php" style="float:right;"><b>Go to Cart</b></a>
                    </div>

                    <div id="products_box">
                        <?php 
                        if(!isset($_SESSION['customer_email'])){
                            include("customer_login.php");
                        }
                        else{
                            include("payment.php");
                        }
                        ?>
                    </div>

                </div>
            </div>
        </main>

        <footer id="fcontact">
            <div class="foocon">
                <div class="row">
                    <div class="col-md-4">
                        <p id="footitle">About Snobbox</p>
                        <p id="footinfo1"> THE SNOBBOX is an international B2C fast fashion e-commerce platform. 
                        The company mainly focuses on women's wear, but it also offers men's apparel, 
                        children's clothes, accessories, shoes, bags and other fashion items.  
                        The brand was founded in December 9.
                    </div>
                    <div class="col-md-4">
                        <p id="footitle">Our Information</p>
                        <ul type="none" id="footinfo1">
                        <a href="index.php"><li>Home</li></a>
                        <a href="index.php"><li>Men's wear</li></a>
                        <a href="index.php"><li>Women's wear</li></a>
                    </div>
                    <div class="col-md-4">
                        <p id="footitle">Store Information</p>
                        <ul type="none" id="footinfo2">
                        <li><i class="fa fa-phone"> Phone Number</i></li>
                        9099617047
                        <br>
                        <li><i class="fa fa-envelope"> Email-address</i></li>
                        gandhiaayushi28@gmail.com
                        <br>
                        <li><i class="fa fa-map-marker"> Location</i></li>
                        Surat
                        <br>
                    </div>
                    
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <p>
                        <center><h3>SIGN UP FOR NEWSLETTER !</h3></center>
                        </p>
                    </div>
                    <div class="col-md-6 emailbox"  >
                        <form action="#" method="post">
                        <input type="email" name="email" placeholder="Enter your email here..."/>
                        <input type="submit" name="submit"/>
                        </form>
                    </div>
                </div>
            </div>
        </footer>
    </body>
</html>

