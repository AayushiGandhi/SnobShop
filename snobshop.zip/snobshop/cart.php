<!DOCTYPE>
<?php session_start();
        include("functions/functions.php");
?>

<html>
    <head>
        <title>Homepage</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="styles/newstyle1.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		
    </head>

    <body>
        <header>
        <!-- header -->
        <div class="headercontainer">
            <div class=" row header-bot">
                <div class="inside-header">
                    <div class="col-md-4 header-middle">
                        <form action="#" method="post">
                            <input type="search" name="search" placeholder="Search here..." required="">
                            <button type="submit" class="searchbutton"><i class="fa fa-search" aria-hidden="true"></i></button>
                            <div class="clearfix"></div>
                        </form>
                    </div>
                    <div class="col-md-4 logo">
                        <p>The Snobshop</p>
                    </div>
                    <div class="col-md-4">
                        
                    </div>
                </div>
            </div>
            <div class="row ">
                <nav class="navbar navbar-inverse navi">
                    <div class="container-fluid navcon">
                        <ul class="nav navbar-nav navibar">
                        <li class="active"><a href="index.php">Home</a></li>
                        <li><a href="#">Shopping Cart</a></li>
                        <li><a href="#fcontact">Contact Us</a></li>
                        </ul>
                    </div>
                </nav>
            </div>

        </div>
        </header>

        <main>
            <div class="main-wrapper">
                <div class="col-md-2 sidebar">
                    <div id="sidebar_title">Categories</div>
                    <ul id="cats">
                        
						<?php getCats(); ?>																																			
                    </ul>
               
					<div id="sidebar_title">Brands</div>
                    <ul id="cats">
                        
                        <?php getBrands(); ?>
                        
                    </ul>
                </div>

                

                <div class="col-md-10 content" style="background-color:white;">
                
                    <div id="shopping_cart">
                     <?php cart(); ?> 

                        <?php 
                            if(isset($_SESSION['customer_email'])){
                                echo "<b>Welcome: </b>" . $_SESSION['customer_email'];
                            }
                            else{
                                echo "<b>Welcome Guest: ";
                            }
                        ?>
                        <!-- <span> Welcome Guest !</span> -->
                        <!-- <b>Shopping Cart </b>
                        Total Items: < ?php total_items(); ?> Total Price: < ?php total_price(); ?> -->
                        <a href="index.php" style='float:right;' ><b>Back To Shop</b></a>
                        <?php 
                            if(!isset($_SESSION['customer_email'])){
                                echo "<a href='checkout.php' style='float:right; padding-right:20px;'><b>Login</b></a>";
                            }
                            else{
                                echo "<a href='logout.php' style='float:right; padding-right:20px;'><b>Logout</b></a>";
                            }
                        ?>
                    </div>

                    <div id="products_box">
                       
                       <form action="cart.php" method="post" enctype="multipart/form-data">
                            <table class="carttable">
                                    <tr id="carttr">
                                        <th>Remove</th>
                                        <th>Product(s)</th>
                                        <th>Quantity</th>
                                        <th>Product Price</th>
                                    </tr>

                                    <?php 
                                        $total = 0;
                                        global $con;
                                        $ip=getIp();
                                        $sel_price = "select * from cart where ip_add='$ip'";
                                        $run_price = mysqli_query($con, $sel_price); 
                                    
                                        while ($p_price=mysqli_fetch_array($run_price)){
                                            $pro_id = $p_price['p_id'];
                                            $pro_price = "select * from products where product_id=$pro_id";
                                            $run_pro_price = mysqli_query($con, $pro_price); 
                                    
                                            while($pp_price=mysqli_fetch_array($run_pro_price)){
                                                $product_price = array($pp_price['product_price']);
                                                $product_title = $pp_price['product_title'];
                                                $product_image = $pp_price['product_image'];
                                                $single_price = $pp_price['product_price'];
                                                $values = array_sum($product_price);
                                                $total += $values;
                                    ?>

                                    <tr>
                                        <td><input type="checkbox" name="remove[]" value="<?php echo $pro_id;?>" /></td>
                                        <td><?php echo $product_title; ?>
                                        <img src="admin_area/product_images/<?php echo $product_image; ?>" width="60px" height="60px" />
                                        </td>
                                        <!-- <td><input type="text" size="6" name="qty" value="<?php echo $_SESSION['qty']; ?>"/></td> -->
                                        <td><select name="qty" >
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                        </select></td>
                                        <?php 
                                                if((isset($_POST['update_cart']))){
                                                    $qty = $_POST['qty'];
                                                    $update_qty = "update cart set qty='$qty'";
                                                    $run_qty = mysqli_query($con, $update_qty);

                                                    $_SESSION['qty'] = $qty;

                                                    $total = $total * $qty;
                                                }
                                        ?>
                                        <td><?php echo "Rs " .$single_price; ?></td>
                                    </tr>
                                    
                                    <?php } } ?>
                                    <tr >
                                        <td colspan="4"><b> Subtotal  </b></td>
                                        <td><?php echo " Rs ".$total ?></td>
                                    </tr>

                                    <tr>
                                        <td><input class="cartbutton" type="submit" name="update_cart" value="Update Cart"/></td>
                                        <td><input class="cartbutton" type="submit" name="continue" value="Continue Shopping" /></td>
                                        <td><button class="cartbutton" ><a href = "checkout.php" style="color:white;"> Checkout </a></button></td>                                    
                                    </tr>
                            </table>

                       <?php 
                            
                            // function updatecart(){

                            global $con;
                            $ip=getIp();
                            
                            if(isset($_POST['update_cart'])){

                                foreach($_POST['remove'] as $remove_id){
                                    $delete_product="delete from cart where p_id='$remove_id' AND ip_add='$ip'";
                                    $run_delete=mysqli_query($con, $delete_product);

                                    if($run_delete){
                                        echo "<script>window.open('cart.php','_self')</script>";
                                    }
                                }
                            }

                            if(isset($_POST['continue'])){
                                echo "<script>window.open('index.php','_self')</script>";
                            }

                             //echo @$up_cart = updatecart();
                             //}
                       ?>
                        </form>
                    </div>

                </div>
            </div>
        </main>

        <footer id="fcontact">
            <div class="foocon">
                <div class="row">
                    <div class="col-md-4">
                        <p id="footitle">About Snobbox</p>
                        <p id="footinfo1"> THE SNOBBOX is an international B2C fast fashion e-commerce platform. 
                        The company mainly focuses on women's wear, but it also offers men's apparel, 
                        children's clothes, accessories, shoes, bags and other fashion items.  
                        The brand was founded in December 9.
                    </div>
                    <div class="col-md-4">
                        <p id="footitle">Our Information</p>
                        <ul type="none" id="footinfo1">
                        <a href="index.php"><li>Home</li></a>
                        <a href="#"><li>Men's wear</li></a>
                        <a href="#"><li>Women's wear</li></a>
                    </div>
                    <div class="col-md-4">
                        <p id="footitle">Store Information</p>
                        <ul type="none" id="footinfo2">
                        <li><i class="fa fa-phone"> Phone Number</i></li>
                        9099617047
                        <br>
                        <li><i class="fa fa-envelope"> Email-address</i></li>
                        gandhiaayushi28@gmail.com
                        <br>
                        <li><i class="fa fa-map-marker"> Location</i></li>
                        Surat
                        <br>
                    </div>
                    
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <p>
                        <center><h3>SIGN UP FOR NEWSLETTER !</h3></center>
                        </p>
                    </div>
                    <div class="col-md-6 emailbox"  >
                        <form action="#" method="post">
                        <input type="email" name="email" placeholder="Enter your email here..."/>
                        <input type="submit" name="submit"/>
                        </form>
                    </div>
                </div>
            </div>
        </footer>
    </body>
</html>
