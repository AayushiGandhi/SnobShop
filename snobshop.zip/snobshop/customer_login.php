<?php 
    include("includes/db.php");
    //include("functions/functions.php"); 
?>

<div class="logincontent">
    <div class="modal-header">
        <h3 class="agileinfo_sign">Sign In <span>Now</span></h3>
    </div>
    <div class="modal-body">
        
        <form action="" method="post" name="form1">
            <div class="styled-input">
                <label>Email</label><br>
                <input type="text" name="emailaddress" onblur="validateEmail();" />
            </div>
            <div class="styled-input"> 
                <label>Password</label><br>
                <input type="password" name="pw" onblur="validatePassword();" />
            </div> 
        <br>
            <input type="submit" value="Sign In" name="login" onclick="validateEmail(); validatePassword();"><br>
            <h4 style="padding:8px; margin-top:15px; font-size:20px;"><a href = "customer_register.php" >New? Register Here ! </a></h4>
        </form>



        <script type="text/javascript">
            function validateEmail(){
                
                var email=document.form1.emailaddress.value;
                var emailPattern=/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{3}$/;
                
                if(email==""){
                    alert("Email must be filled out");
                }
                else if(emailPattern.test(email)==false){
                    alert("Invalid email address");
                    return false;
                }    
                return false;
            }

            function validatePassword(){
                var password=document.form1.pw.value;
                var passwordPattern=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,12}$/;

                if(password==""){
                    alert("Password must be filled out");
                }
                else if(password.match(passwordPattern)){
                     return true;
                }
                else{
                    alert("Paswword must be of length 6 to 12 characters which contain atleast one lower case, one upper case letter and one numeric digit ");
                    return false;
                    }
            }
        
        </script>


       <?php 
        global $con;
        if(isset($_POST['login'])){

            $c_email = $_POST['emailaddress'];
            $c_pass = $_POST['pw'];

            $sel_c = "select * from customers where customer_pass = '$c_pass' AND customer_email = '$c_email'";
            $run_c = mysqli_query($con, $sel_c);

            $check_customer = mysqli_num_rows($run_c);
            if($check_customer==0){
                echo "<script>alert('Password or email is incorrect , please try again !')</script>";
                exit();
            }


            $ip = getIp();
            $sel_cart = "select * from cart where ip_add='$ip'";
		    $run_cart = mysqli_query($con, $sel_cart);

            $check_cart = mysqli_num_rows($run_cart);
            
            if($check_customer > 0 AND $check_cart == 0){

                $_SESSION['customer_email']=$c_email;
                echo "<script>alert('You logged in successfully !')</script>";
                //echo "<script>window.open('customer/my_account.php','_self')</script>";
                echo "<script>window.open('index.php','_self')</script>";
            }
            else{
                $_SESSION['customer_email']=$c_email;
			    echo "<script>alert('You logged in successfully !')</script>";
			    echo "<script>window.open('checkout.php','_self')</script>";
            }
        }

?>


    </div>
</div>

